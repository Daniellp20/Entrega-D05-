/*
 * CardService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.CardRepository;
import security.LoginService;
import security.UserAccount;
import domain.Card;
import domain.Customer;

@Service
@Transactional
public class CardService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private CardRepository	cardRepository;

	// Supporting services ----------------------------------------------------

	@Autowired
	private CustomerService	customerService;


	// Constructors -----------------------------------------------------------

	public CardService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Card create() {
		Card result;
		Customer customer;

		customer = this.customerService.findByPrincipal();

		result = new Card();
		result.setCustomer(customer);

		return result;
	}

	public Collection<Card> findByPrincipal() {
		Collection<Card> result;
		UserAccount userAccount;

		userAccount = LoginService.getPrincipal();
		result = this.cardRepository.findByUserAccount(userAccount);

		return result;
	}

	public Card findOne(final int cardId) {
		Card result;

		result = this.cardRepository.findOne(cardId);

		return result;
	}

	public Card findOneToEdit(final int cardId) {
		Card result;

		result = this.findOne(cardId);
		this.checkPrincipal(result);

		return result;
	}

	public void save(final Card card) {
		this.checkPrincipal(card);
		this.cardRepository.save(card);
	}

	public void delete(final Card card) {
		this.checkPrincipal(card);
		this.cardRepository.delete(card);
	}

	// Other business methods -------------------------------------------------

	protected void checkPrincipal(final Card card) {
		Customer customer;

		customer = this.customerService.findByPrincipal();
		Assert.isTrue(card.getCustomer().equals(customer));
	}

}
